Quadratic-growth weighted Signorini classification
Fu Xiaonan, October 7, 2026

This source builds the complete intrinsic classification in bulk R3 / thin R2
for negative weight exponent eta=1-2s, 1/2<s<1, and at most quadratic growth.
Its late companion theorem treats the all-order ordinary-tail rank-one problem.

Compile: sh build.sh
Output: parabolic_rigidity.pdf
The build uses pdfLaTeX and BibTeX from a standard TeX Live installation. No
network access or shell escape is needed. The bundled .bbl is the current
bibliography, but the build regenerates it from references.bib.

All mathematical proofs used by the manuscript are in the bundled TeX modules;
references to published literature identify the external theorems used. The
six models, their pressures, exact parameters, and extension conventions are
in catalogue.tex. The source/energy formulation and zero-target case are
explicit. The sharp remainder corollary is a consequence after classification.

The manuscript includes a truthful section-linked disclosure of AI assistance
with mathematical ideas and proof development. Independent human verification
remains pending. This is a research manuscript, not a formal proof certificate
or a claim of submission readiness.
