#!/usr/bin/env sh
# Requires a standard TeX Live installation with pdfLaTeX and the packages
# declared in parabolic_rigidity.tex. No network access or shell escape. BibTeX reads the bundled references.bib.
set -eu
cd "$(dirname "$0")"
export SOURCE_DATE_EPOCH=1791331200
export FORCE_SOURCE_DATE=1
export TZ=UTC
mkdir -p build
# Normally the installed TeX tree and formats work without any customization.
# The fallback supports read-only Linux images with uninitialized TeX caches.
if ! kpsewhich amsart.cls >/dev/null 2>&1; then
  export TEXMFVAR="$PWD/build/texmfvar"
  export TEXMFCONFIG="$PWD/build/texmfconfig"
  export TEXMF="{$TEXMFVAR,/usr/share/texlive/texmf-dist,/usr/share/texmf,/etc/texmf}"
  export TEXFORMATS="$TEXMFVAR/web2c//"
  mkdir -p "$TEXMFVAR/web2c/pdftex" "$TEXMFCONFIG"
  if [ ! -f "$TEXMFVAR/web2c/pdftex/pdflatex.fmt" ]; then
    (cd "$TEXMFVAR/web2c/pdftex" && pdftex -ini -etex -jobname=pdflatex -interaction=nonstopmode '\input pdflatex.ini') >build/bootstrap.log 2>&1
  fi
  mkdir -p "$TEXMFVAR/fonts/map/pdftex"
  if [ ! -f "$TEXMFVAR/fonts/map/pdftex/pdftex.map" ]; then
    for fontmap in cm.map cmextra.map symbols.map euler.map lm.map; do
      cat "$(kpsewhich "$fontmap")"
    done > "$TEXMFVAR/fonts/map/pdftex/pdftex.map"
  fi
fi
pdflatex -interaction=nonstopmode -halt-on-error -file-line-error -output-directory=build parabolic_rigidity.tex > build/pass1.txt 2>&1
(cd build && BIBINPUTS=..: bibtex parabolic_rigidity > bibtex.txt 2>&1)
for pass in 2 3; do
  pdflatex -interaction=nonstopmode -halt-on-error -file-line-error -output-directory=build parabolic_rigidity.tex > "build/pass${pass}.txt" 2>&1
done
cp build/parabolic_rigidity.pdf parabolic_rigidity.pdf
printf '%s\n' 'Built parabolic_rigidity.pdf'
